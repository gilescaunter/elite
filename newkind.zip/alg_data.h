/* Allegro datafile object indexes, produced by grabber v3.9.32 (WIP), Mingw32 */
/* Datafile: c:\usr\cprogs\NewKind\elite.dat */
/* Date: Mon May 07 19:20:00 2001 */
/* Do not hand edit! */

#define BLAKE                            0        /* BMP  */
#define DANUBE                           1        /* MIDI */
#define ECM                              2        /* BMP  */
#define ELITE_1                          3        /* FONT */
#define ELITE_2                          4        /* FONT */
#define ELITETXT                         5        /* BMP  */
#define FRONTV                           6        /* BMP  */
#define GRNDOT                           7        /* BMP  */
#define MISSILE_G                        8        /* BMP  */
#define MISSILE_R                        9        /* BMP  */
#define MISSILE_Y                        10       /* BMP  */
#define REDDOT                           11       /* BMP  */
#define SAFE                             12       /* BMP  */
#define THEME                            13       /* MIDI */

