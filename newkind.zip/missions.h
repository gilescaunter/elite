#ifndef MISSIONS_H
#define MISSIONS_H

char *mission_planet_desc (struct galaxy_seed planet);
void check_mission_brief (void);

#endif