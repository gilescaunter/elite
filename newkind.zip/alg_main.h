
#ifndef MAIN_H
#define MAIN_H

void info_message (char *message);

#endif