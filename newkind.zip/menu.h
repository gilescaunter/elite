#define MENU_FILE       0
#define MENU_HELP       1

#define IDM_EXIT        1
#define IDM_ABOUT       2
