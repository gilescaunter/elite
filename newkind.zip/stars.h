#ifndef STARS_H
#define STARS_H

extern int warp_stars;

void create_new_stars (void);
void update_starfield (void);
void flip_stars (void);

#endif

